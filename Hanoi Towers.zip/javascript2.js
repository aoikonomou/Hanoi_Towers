var rods = [[0,0,0,],[0,0,0],[0,0,0]];	

var diskNotPlaced = true;


function putDisk(diskNum, rodNum){

	while (diskNotPlaced)

	{

		if (rods[rodNum][0] == 0) { //If the botom position of the rod is empty...

			rods[rodNum][0] = diskNum; //...put the disk there
			alert("I am in rod 1");
			emptyPreviousLocation()
			diskNotPlaced = false;
			return true; //...exit the function

		} else {

			if (rods[rodNum][1] == 0 || rods[rodNum][0] < diskNum ) { // if the position immediately above is empty and the disk below is not smaller..

				rods[rodNum][1] = diskNum; //... put the disk there
				alert("I am in rod 2");
				diskNotPlaced = false;
				return true; //...exit the function

			} else {

				if (rods[rodNum][0] == 0 || rods[rodNum][0] < diskNum ) { // if the position immediately above is empty and the disk below is not smaller..

					rods[rodNum][2] = diskNum; //... put the disk there
					alert("I am in rod 3");
					diskNotPlaced = false;
					return true; //...exit the function

				}

			}
		}
	}
	tellMe(); // This function shows the contents of the rods array. In this case we want to see the contents after the above has happened

}


function emptyPreviousLocation(diskNum, rodNum, diskPreviousLocation) {

	for (var i = 0; i<3; i++) {

		for (var j = 0; j<3; j++){

			 // One idea here is to scan the whole array for duplicate disks in places other than the one it was recently positioned but is this the best way?
		}
	}
}


}


function tellMe(){
	for (var i = 0; i<3; i++) {

		for (var j = 0; j<3; j++){

			 document.getElementById("debugArea").innerText += "\n Rod "+ i + " position "+j+" has "+ rods[i][j]+" in it";
		}
	}
}